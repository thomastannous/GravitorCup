// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GGravityBallGameMode.h"
#include "GGravityBall2v2GameMode.generated.h"

/**
 * 
 */
UCLASS()
class GRAVITORCUP_API AGGravityBall2v2GameMode : public AGGravityBallGameMode
{
	GENERATED_BODY()
	
};
