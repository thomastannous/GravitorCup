// Fill out your copyright notice in the Description page of Project Settings.


#include "GGameInstance.h"

#include "GravitorCup.h"

void UGGameInstance::Init()
{
    Super::Init();

}

void UGGameInstance::RemoveAllUnutilizedPlayers()
{
    TArray<ULocalPlayer*> PlayersToDelete;
    for(ULocalPlayer *LP : LocalPlayers)
    {
        if(!JoinedLocalPlayers.Contains(LP))
        {
            PlayersToDelete.Add(LP);
        }
    }

    for(ULocalPlayer *LP : PlayersToDelete)
    {
        RemoveLocalPlayer(LP);
    }
}

